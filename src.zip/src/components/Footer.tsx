import '../footer.css';
import { logo } from '../data/content';
import { ADDRESS, CONTACT, FB_LINK } from '../data/location';
import { FacebookIcon } from './icons';
import MapCard from './MapCard';
import { useAdStore } from '../store/useAdStore'; // Adjust path if needed

export default function Footer() {
  // Assuming you add an action or setter in your store to switch views, e.g., setView('admin')
  // or setTab('admin') / openAdmin()
  const setTab = useAdStore((state) => state.setTab); // or your specific admin trigger

  return (
    <footer id="location">
      <div className="wrap">
        <img src={logo} alt="Paddle Alley" />
        <div>
          <h3>Play starts here.</h3>
          <p>{ADDRESS}</p>
          <p>{CONTACT}</p>
          <a className="fb-link" href={FB_LINK} target="_blank" rel="noreferrer">
            <FacebookIcon />
            Find us on Facebook
          </a>
          {/* Staff portal link */}
          <div style={{ marginTop: '1.5rem' }}>
            <button 
              type="button"
              onClick={() => setTab('admin' as Parameters<typeof setTab>[0])} 
              style={{ background: 'none', border: 'none', padding: 0, color: 'inherit', textDecoration: 'underline', cursor: 'pointer', fontSize: 'inherit' }}
            >
              Staff portal
            </button>
          </div>
        </div>
        <MapCard />
      </div>
    </footer>
  );
}